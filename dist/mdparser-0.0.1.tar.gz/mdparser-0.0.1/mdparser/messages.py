# 文件不存在
FILE_NOT_EXISTS = "file '{0}' not exists"


# 未知的异常信息

UNHANDLED_EXCEPTION = "unhandled exception inner error info : '{0}' "
